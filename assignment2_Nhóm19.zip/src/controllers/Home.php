<?php
class Home extends Controller {

    function show() {
        $this->View("home", []);
    }
}
?>