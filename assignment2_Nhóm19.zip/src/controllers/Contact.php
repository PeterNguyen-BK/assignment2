<?php
class Contact extends Controller {

    function show() {
        $this->View("contact", []);
    }
}
?>