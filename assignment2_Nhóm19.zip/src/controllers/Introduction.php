<?php
class Introduction extends Controller {
    function show() {
        $this->View("introduction", []);
    }
}
?>