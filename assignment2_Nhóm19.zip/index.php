<?php
session_start();
require_once "./src/core/App.php";
require_once "./src/core/Controller.php";
require_once "./src/core/Config.php";
$myApp = new App();
?>